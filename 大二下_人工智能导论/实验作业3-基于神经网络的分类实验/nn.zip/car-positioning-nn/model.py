from torch import nn
from torch.nn import Sequential, Linear, ReLU, Dropout


class DisFit(nn.Module):
    def __init__(self):
        super(DisFit, self).__init__()
        self.model = Sequential(
            Linear(10, 24),
            ReLU(True),
            Dropout(),
            Linear(24, 24),
            ReLU(True),
            Dropout(),
            Linear(24, 5)
        )

    def forward(self, x):
        x = self.model(x)
        return x
