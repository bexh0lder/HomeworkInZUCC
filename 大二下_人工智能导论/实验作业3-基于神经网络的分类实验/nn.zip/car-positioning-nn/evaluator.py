import numpy as np
import torch


def get_accuracy(model, data_loader):
    model.eval()

    truths = []
    preds = []
    for x, y in data_loader:
        model.eval()
        x = x.cuda()
        y = y.cuda()
        predict = model(x)

        truths.append(y.cpu().squeeze().numpy())
        preds.append(predict.cpu().squeeze().numpy())

    loss_fn = torch.nn.MSELoss()
    truths_array = np.asarray(truths).T
    preds_arraay = np.asarray(preds).T
    truths_tensor = torch.from_numpy(truths_array).float()
    preds_tensor = torch.from_numpy(preds_arraay).float()

    return loss_fn(preds_tensor, truths_tensor)
