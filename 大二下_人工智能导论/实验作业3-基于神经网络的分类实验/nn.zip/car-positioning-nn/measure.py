class Measure:
    def __init__(self, gt_dist, mea_dist, fp_level_poll, rx_level_poll, fp_level_final, rx_level_final, base_id, in_out):
        self.gt_dist = gt_dist
        self.mea_dist = mea_dist
        self.fp_level_poll = fp_level_poll
        self.rx_level_poll = rx_level_poll
        self.fp_level_final = fp_level_final
        self.rx_level_final = rx_level_final
        self.base_id = base_id
        self.in_out = in_out
