import torch

import os
import numpy as np
from measure import Measure


def calc_dist(a, b):
    return np.linalg.norm(a - b)


def calc_dists2bases(a, bases):
    dists = []
    for b in bases:
        dists.append(calc_dist(a, b))
    dists = np.asfarray(dists)
    return dists


class UWBDataSet(torch.utils.data.Dataset):
    def __init__(self, file_path):
        self.base_num = 5
        base_coords = np.zeros((self.base_num, 3))
        with open(os.path.join(file_path, 'bases.txt'), 'r') as f:
            lines = f.readlines()
            for line in lines:
                lhs = line.split(';')[0].split('=')[0]
                base_i = int(lhs.split('[')[1].split(']')[0])
                # print(base_num)
                sub_strs = line.split(';')
                val = np.asfarray([eval(sub_str.split('=')[1]) for sub_str in sub_strs if "=" in sub_str])
                base_coords[base_i] = val
        file_list = os.listdir(os.path.join(file_path, 'measures'))
        self.measures = []
        self.len = 0

        for file_name in file_list:
            with open(os.path.join(file_path, 'measures', file_name), 'r') as f:
                lines = f.readlines()
                started = False
                cnt = 0
                if file_name[0:2] == 'in':
                    in_out = 'in'
                else:
                    in_out = 'out'
                    # continue
                # print(in_out)
                for line in lines:
                    try:
                        first_word = line.split(':')[0]
                        first_val_strs = line.split('(')[1].split(')')[0].split(',')
                        first_val_np = np.asfarray([float(str_i) for str_i in first_val_strs])
                        if first_word == 'gt_coord':
                            gt_coord = first_val_np
                            gt_dists = calc_dists2bases(gt_coord, base_coords)
                        elif first_word == 'dists':
                            if not started:
                                started = True
                            mea_dists = first_val_np
                        elif first_word == 'rx_level_poll':
                            # print(first_word)
                            rx_level_polls = first_val_np
                        elif first_word == 'fp_level_poll':
                            fp_level_polls = first_val_np
                        elif first_word == 'fp_level_final':
                            fp_level_finals = first_val_np
                        elif first_word == 'rx_level_final':
                            rx_level_finals = first_val_np
                            if started:
                                tmp_measure = []
                                for i in range(self.base_num):
                                    tmp_measure.append(
                                        Measure(gt_dists[i], mea_dists[i], fp_level_polls[i], rx_level_polls[i],
                                                fp_level_finals[i], rx_level_finals[i], i, in_out))
                                self.measures.append(tmp_measure)
                                cnt += 1
                                if cnt >= 50:
                                    break
                    except Exception as e:
                        pass

    def __len__(self):
        return len(self.measures)

    def __getitem__(self, idx):
        x_list = []
        y_list = []
        for i in range(self.base_num):
            x_list.append(self.measures[idx][i].mea_dist)
            x_list.append(self.measures[idx][i].fp_level_poll)
            y_list.append(self.measures[idx][i].gt_dist)

        x_array = np.asfarray(x_list, dtype=float)
        y_array = np.asfarray(y_list, dtype=float)
        x_tensor = torch.from_numpy(np.float32(x_array))
        y_tensor = torch.from_numpy(np.float32(y_array))

        return x_tensor, y_tensor


if __name__ == '__main__':
    dataset = UWBDataSet('data/2022年4月20日静态数据')
    print(dataset[0])
    print(len(dataset))
