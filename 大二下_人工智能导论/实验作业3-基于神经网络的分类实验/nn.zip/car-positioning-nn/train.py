from shutil import copyfile
from dataset import UWBDataSet
from measure import Measure
from model import DisFit
import torch
import argparse
from torch.utils.data import DataLoader
import os
import numpy as np
from timeit import default_timer as timer
from evaluator import get_accuracy
import math

parser = argparse.ArgumentParser(description='UWB')

parser.add_argument('--cuda',        type=int,   default=0,    help='cuda number (default: 1)')
parser.add_argument('--output_dir',   type=str,   default='./results/model_weights/main/', help='output_dir')

parser.add_argument('--data_dir',   type=str,   default='./data/2022年4月20日静态数据', help='output_dir')
parser.add_argument('--epochs',      type=int,   default=200,  help='number of epochs (default: 5)')
parser.add_argument('--batch_size',  type=int,   default=5,   help='batch size for training (default: 32)')
parser.add_argument('--lr',          type=float, default=0.0001, help='learning rate (default: 5e-3)')


params = parser.parse_args()
print(params)

torch.cuda.set_device(params.cuda)

dataset = UWBDataSet(params.data_dir)
length = len(dataset)
train_size, validate_size = int(0.8*length), int(0.2*length)
train_dataset, test_dataset = torch.utils.data.random_split(dataset, [train_size, validate_size])
train_data_loader = DataLoader(train_dataset, batch_size=params.batch_size, shuffle=True,)
test_data_loader = DataLoader(test_dataset, batch_size=1)

model = DisFit()
model = model.cuda()

loss_fn = torch.nn.MSELoss()
loss_fn = loss_fn.cuda()
optimizer = torch.optim.Adam(model.parameters(), lr=params.lr)
loss_best = math.inf

for epoch in range(params.epochs):
    start_time = timer()

    losses = []
    model.train()
    for x, y in train_data_loader:
        x = x.cuda()
        y = y.cuda()
        predict = model(x)
        
        loss_val = loss_fn(predict, y)
        loss_val.backward()
        losses.append(loss_val.data.cpu().numpy())
        optimizer.step()
    
    with torch.no_grad():
        loss = get_accuracy(model, test_data_loader)
        print(
            "Epoch {} : 平均训练集Loss: {:.5f}, 验证集Loss: {:.5f}, Time elapsed {:.2f} s".format(
                epoch + 1,
                np.mean(losses),
                loss,
                timer() - start_time
            )
        )
        if loss < loss_best:
            stopping_step = 0
            print("loss reduced....saving weights !!")
            best_loss_epoch = epoch + 1
            loss_best = loss
            output_dir = params.output_dir
            os.makedirs(output_dir, exist_ok=True)
            model_path = output_dir + "epoch{}_loss_{:.5f}.pth".format(epoch + 1, loss)
            torch.save(model.state_dict(), model_path)
            print("model saved in " + model_path)

    if epoch + 1 == params.epochs:
        best_model_path = output_dir + "epoch{}_loss_{:.5f}.pth".format(best_loss_epoch, loss_best)
        copyfile(best_model_path, output_dir + "final.pth")
        print("the model " + model_path + " is saved in " + model_path)
